﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MissingElement_integer
{
    class Program
    {
        const int maxSize = 100000;
        static void Main(string[] args)
        {
            int[] A = { 1,2,5,3};
           
            Console.WriteLine(solution(A));
            //foreach (int number in A)
            //{
            //    if (number > 0 && number <=maxSize)
            //    {
            //        counter[number - 1] = 1;
            //    }
            //}
            //foreach (var item in counter)
            //{
            //    Console.WriteLine(item);
            //}
            //for (int i = 0; i <maxSize; i++)
            //{
            //    if (counter[i]==0)
            //    {
            //        Console.WriteLine(i+1);
            //    }
            //}
            //Console.WriteLine(maxSize+1);
            Console.ReadKey();
        }
        public static int solution(int[] A)
        {
            int[] counter = new int[maxSize];

            foreach (int number in A)
            {
                if (number > 0 && number <= maxSize)
                {
                    counter[number - 1] = 1;
                }
            }

            for (int i = 0; i < maxSize; i++)
            {
                if (counter[i] == 0)
                {
                    return i + 1;
                }
            }

            return maxSize + 1;
        }
    }
}
