﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinperimeterRectangle
{
    class Program
    {
        static void Main(string[] args)
        {

            int n = 30;
            Console.WriteLine(solution(n));
            Console.ReadKey();
        }
        public static int solution(int N)
        {

       
            int permiter = (int) (2 * (Math.Sqrt(N) + 6));
            return permiter;


            

        }
    }
}
