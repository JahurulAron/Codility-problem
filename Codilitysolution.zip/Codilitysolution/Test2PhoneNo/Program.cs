﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test2PhoneNo
{
    class Program
    {

        static void Main(string[] args)
        {
            //	00-44  48 5555 8361 -> 004-448-555-583-61 (14 sign)
            //	0 - 22 1985--324    -> 022-198-53-24      (10 sign)
            //	555372654           -> 555-372-654        (9 sign)
            string B = "00-44  48 5555 8361";
            Console.WriteLine(solution(B));

            //string case1 = "00-44  48 5555 8361";
            //string case2 = "0 - 22 1985--324";
            //string case3 = "555372654";
            //Console.WriteLine("case1: " + solution(case1)); //case1: 004-448-555-583-61
            //Console.WriteLine("case2: " + solution(case2)); //case2: 022-198-53-24
            //Console.WriteLine("case3: " + solution(case3)); //case3: 555-372-654
            Console.ReadKey();

        }
        public static string solution(string phoneNumber)
        {
            phoneNumber = removeNonDigits(phoneNumber);
            return formatPhoneNumber(phoneNumber, checkNumberSize(phoneNumber));
        }

        private bool checkNumberSize(string phoneNumber)
        {
            return phoneNumber.Length % 3 == 1;
        }

        private string removeNonDigits(string s)
        {
            return s.Replace("[^0-9]", "");
        }

        private string formatPhoneNumber(string s, bool lastGroup)
        {
            string tempNumber = "";
            int dashCounter = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (dashCounter < 3)
                {
                    tempNumber = tempNumber + (s.Substring(i, i + 1));
                    dashCounter++;
                }
                else if (dashCounter == 3)
                {
                    tempNumber = tempNumber + ("-");
                    tempNumber = tempNumber + (s.Substring(i, i + 1));
                    dashCounter = 1;
                }
            }
            if (lastGroup)
            {
                char[] temp = tempNumber.ToCharArray();
                temp[temp.Length - 2] = temp[temp.Length - 3];
                temp[temp.Length - 3] = '-';
                tempNumber = new string(temp);
            }
            return tempNumber;
        }
    }
}