﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrogJump
{
    class Program
    {
        static void Main(string[] args)
        {
           int x = 10;
           int y= 85;
           int d = 30;
            Console.WriteLine(solution(x,y,d));
            Console.ReadKey();
        }
        public static int solution(int X,int Y, int D)
        {


            int output= (int)Math.Ceiling(((double)Y - X) / D);
            return output;




        }
    }
}
