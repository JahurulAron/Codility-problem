﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Phoneno
{
    class Program
    {
        static void Main(string[] args)
        {
            string txt = "456-789-678-99-90";

            string re1 = "(\\d+)";  // Integer Number 1

            Regex r = new Regex(re1, RegexOptions.IgnoreCase | RegexOptions.Singleline);
            Match m = r.Match(txt);
            if (m.Success)
            {
                String int1 = m.Groups[1].ToString();
                string int2 = m.Groups[2].ToString();
                Console.Write("(" + int1.ToString() + ")"+"*" +int2.ToString()+ "\n");
            }
            Console.ReadLine();
        }
    }
}
