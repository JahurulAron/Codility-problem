﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrogRiverOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = { 1,3,1,4,2,3,5,4 };
            int x = 5;
            Console.WriteLine(solution(x,A));

            Console.ReadKey();
        }
        public static int solution(int X, int[] A)
        {
            // write your code in C# 6.0 with .NET 4.5 (Mono)

            int N = A.Length;

            bool[] isNotThere = new bool[X + 1];

            for (int i = 0; i < isNotThere.Length; i++)
            {
                isNotThere[i] = true;
            }

            int counter = 0;

            for (int i = 0; i < N; i++)
            {
                if ((A[i] <= X) && isNotThere[A[i]])
                {
                    isNotThere[A[i]] = false;
                    counter++;

                    if (counter == X)
                    {
                        return i;
                    }
                }
            }

            return -1;
        }
    }
}
