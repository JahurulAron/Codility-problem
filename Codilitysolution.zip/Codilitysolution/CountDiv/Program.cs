﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountDiv
{
    class Program
    {
        static void Main(string[] args)
        {
            int A = 6;
            int B = 11;
            int K = 2;
            Console.WriteLine(solution(A,B,K));
            Console.ReadKey();

        }
        public static int solution(int A, int B, int K)
        {
            var list = new List<int>();
            for (int i = 6; i <= 11; i++)
            {


                if (i % K == 0)
                {
                    list.Add(i);

                }

            }
            return list.Count;
            //Console.WriteLine(list.Count);
            //var mod = A % K;
            //var output= (mod == 0 ? 1 : 0) + (B + mod - A) / K;
            //Console.WriteLine(output);
        }
    }
}
