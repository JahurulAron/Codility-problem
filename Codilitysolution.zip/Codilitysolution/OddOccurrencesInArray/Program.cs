﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OddOccurrencesInArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = { 9,3,9,3,9,7,9};
            Console.WriteLine(solution(A));
            Console.ReadKey();

        }
        public static int solution(int[] A)
        {
            var has = new HashSet<int>();
            foreach (var i in A)
                if (has.Contains(i))
                    has.Remove(i);
                else
                    has.Add(i);
            foreach (var i in has)
                return i;
            return 0;
        }
    }
}
