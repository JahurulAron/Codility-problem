﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1mulitilply4
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] B = { -6, -91, 1011, -100, 84, -22, 0, 1, 473 };
            Console.WriteLine(solution(B));
            Console.ReadKey();
        }
            public static int solution(int[] A) {

                Array.Sort(A);

                int[] C = new int[A.Length];
                for (int i = 0; i < A.Length; i++)
                {
                    if (A[i] % 4 == 0)
                    {
                        C[i] = A[i];
                    }
                }

                return(C[0]);
            }

        }
    }

