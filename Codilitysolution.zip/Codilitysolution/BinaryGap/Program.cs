﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryGap
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1041;
          
            Console.WriteLine(solution(i));
            Console.ReadKey();
        }

        public static int solution(int N)
        {
            bool started = false;
            int length = 0, max = 0;
            for (uint i = 1; i <= N; i <<= 1)
            {
                if ((i & N) != 0)
                {
                    if (started)
                    {
                        if (length > max)
                            max = length;
                        length = 0;
                    }
                    started = true;
                }
                else if (started)
                    ++length;
            }
            return max;
        }
    }
}
