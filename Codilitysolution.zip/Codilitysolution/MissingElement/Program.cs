﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MissingElement
{
    class Program
    {
       const int maxSize = 100000;
        static void Main(string[] args)
        {
            int[] A = { 1,2,3};
            Console.WriteLine(solution(A));

            Console.ReadKey();
        }
        public static int solution(int[] A)

        {

            //int[] counter = new int[maxSize];

            //foreach (int number in A)
            //{
            //    if (number > 0 && number <= maxSize)
            //    {
            //        counter[number - 1] = 1;
            //    }
            //}

            //for (int i = 0; i < maxSize; i++)
            //{
            //    if (counter[i] == 0)
            //    {
            //        return i + 1;
            //    }
            //}

            //return maxSize + 1;
            //or
            //    public static int solution(int[] A)
            //    {
            //        long arraySum = 0;
            //        foreach (int i in A) // A.Sum() breaks as it uses Int32
            //        {
            //            arraySum += i;
            //        }

            //        // calculate theorical sum
            //        long n = A.Length + 1;
            //        long theoricalSum = (n * (n + 1)) / 2; // notice long as return type to avoid overflow

            //        // return difference
            //        return (int)(theoricalSum - arraySum);
            //   // }
            int num = 1;
            List<int> lists = new List<int>();


            for (int i = 0; i < A.Length; i++)
            {
                lists.Add(A[i]);
            }

            while (lists.Contains(num))
            {
                num++;
            }
            return num;
        }
    }
}