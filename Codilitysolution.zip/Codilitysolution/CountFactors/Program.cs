﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountFactors
{
    class Program
    {
        
        static void Main(string[] args)
        {
            int i = 24;
            Console.WriteLine(solution(i));
            Console.ReadKey();
        }
            public static int solution(int N)
        {
            
            int end = (int)Math.Sqrt(N);

            int count = 0, i = 1;
            while (++i <= end)
            {
                if (N % i == 0)
                    ++count;
            }
            var g = count * 2 + (end * end == N ? 1 : 2);
            return g;
         

        }
    }
}
