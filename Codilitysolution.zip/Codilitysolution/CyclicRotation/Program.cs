﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyclicRotation
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] A = {3,8,9,7,6 };
            int k = 3;
            //int n = A.Length;
            //int[] B = new int[n];

            //for (int i = 0; i < n; i++)
            //{
            //    B[(i + k) % n] = A[i];
            //}

            //foreach (var item in B)
            //{
            //    Console.Write(item);

            //}

            Console.WriteLine(solution(A, k));
            Console.ReadKey();
            
        }
        public static int[] solution(int[] A, int K)
        {
            int n = A.Length;
            int [] B  = new int[n];
          
            for (int i = 0; i < n; i++)
            {
            B[(i + K) % n] = A[i];
            
            }

            return B;
        } 
    }
}
