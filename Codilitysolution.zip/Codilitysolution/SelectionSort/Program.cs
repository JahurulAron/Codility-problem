﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelectionSort
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = { 1,2,3,5,7,8 };
            Console.WriteLine(Sort(A));

            Console.ReadKey();
        }

        public static int[] Sort(int[] arr)
        {
            var n = arr.Length;
            var ops = 0;

            for (int i = 0; i < n; i++)
            {
                var minimal = i;

                for (int j = i + 1; j < n; j++)
                {
                    if (arr[minimal] > arr[j])
                    {
                        minimal = j;
                    }

                    ops++;
                }

                var temp = arr[i];
                arr[i] = arr[minimal];
                arr[minimal] = temp;
            }

            Console.WriteLine("n: " + n + ", ops: " + ops);
            return arr;
        }
    }
}
