﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonacciNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            

                var a = 0;
                var b = 1;
            Console.Write(a+" "+b+" ");
                for (int i = 2; i < 10; i++)
            {
                var x = a + b;
                a = b;
                b = x;

                
                Console.Write($" {x}");
              
            }
            
         
            Console.ReadKey();
        }
    }
}
