﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassingCar
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = new int[] { 0,1,0,1,1 };
            Console.WriteLine(solution(A));

            Console.ReadKey();
        }
        public static int solution(int[] A)
        {
            int pairs = 0, east = 0;
            if (A.Length > 1)
                foreach (var i in A)
                {
                    if (i == 0)
                        ++east;
                    else if (east > 0 && (pairs += east) > 1e9)
                        return -1;
                }
            return pairs;
        }
    }
}