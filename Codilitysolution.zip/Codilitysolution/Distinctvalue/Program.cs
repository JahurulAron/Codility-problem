﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distinctvalue
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = { 1, 2, 3, 1, 2, 3 };
            Console.WriteLine(Solution(A));
            // Console.WriteLine(A.Distinct().Count());
            Console.ReadKey();

        }

        public static int Solution(int[] A)
        {



            var counter = new List<int>();

            foreach (var number in A)
            {
                if (!counter.Contains(number))
                {
                    counter.Add(number);
                }
            }

            return counter.Count;



            //}
            //or is not working why
            //public static int Solution(int[] A)
            //{

            //    var counter = new  List<int>();
            //    for (int i = 0; i < A.Length; i++)
            //    {
            //        counter.Add(i);
            //    }
            //    return counter.Distinct().Count();
            //}
        }

    }
}

