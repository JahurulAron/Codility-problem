﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Permutation
{
    class Program
    {
        private const int maxLength = 100000;
        private const int isPermutation = 1;
        private const int isNotPermutation = 0;
        //q-https://app.codility.com/programmers/lessons/4-counting_elements/perm_check/
        static void Main(string[] args)
        {
            int[] A = { 1,2,4 };
            Console.WriteLine(solution(A));

            Console.ReadKey();
        }
        public static int solution(int[] A)
        {

            int length = A.Length;

            int[] countingArray = new int[maxLength]; // initialized to 0 by default

            for (int i = 0; i < length; i++)
            {
                if (A[i] > maxLength)
                {
                    return isNotPermutation;
                }
                else
                {
                    countingArray[A[i] - 1] = 1;
                }
            }

            for (int i = 0; i < length; i++)
            {
                if (countingArray[i] == 0)
                {
                    return isNotPermutation;
                }
            }

            return isPermutation;
        }
        //public static int solution(int[] A)
        //{
        //    var set = new HashSet<int>();
        //    int max = 1;
        //    int sum = A.Length;
        //    int length = A.Length;
        //    for (int i = 0; i < length; i++)
        //    {
        //        sum += i;

        //        sum -= A[i];

        //        set.Add(A[i]);

        //        if (A[i] > max)
        //            max = A[i];
        //    }

        //    if (max != length || sum != 0 || set.Count != length)
        //        return 0;

        //    return 1;
        //}
    }
}
