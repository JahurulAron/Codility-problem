﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PalindromeString
{
    class Program
    {
        static void Main(string[] args)
        {
            string s1 = "";
            s1 = Console.ReadLine();
            char[] arr = s1.ToCharArray();
            int counts = 0;
            for (int i = 0; i < s1.Length; i++)
            {
                if (arr[i]>='0' && arr[i]<='9')
                {
                    counts+=1;
                }
            }
            Console.WriteLine(counts);


            Console.ReadKey();
        }
    }
}
